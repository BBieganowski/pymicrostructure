"""Metrics for both trader and market performance."""
