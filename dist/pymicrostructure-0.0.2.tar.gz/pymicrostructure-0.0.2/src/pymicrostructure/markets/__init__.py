"""Market models for microstructure simulation."""
