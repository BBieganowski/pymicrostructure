"""Trader types including market makers, informed traders, and noise."""
