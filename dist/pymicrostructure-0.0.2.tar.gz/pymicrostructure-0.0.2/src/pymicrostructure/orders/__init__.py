"""Order types definitions."""
