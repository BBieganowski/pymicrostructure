"""Order types definitions."""
